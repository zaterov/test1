pyStatus
========

Python tool to use with i3bar


Requirements
------
    - psutil
    - python-musicpd
    - netifaces
    - basiciw

Easy installation with pip is possible:

``pip install -r requirements.txt``

Installation
-------
Just edit one line in your ~/.i3/config file and set
status_command to the runner.py

e.g:
"status_command ~/workspace/python/pyStatus/runner.py"

